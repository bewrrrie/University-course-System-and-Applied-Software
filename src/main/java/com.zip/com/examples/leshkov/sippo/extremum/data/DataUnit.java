package com.examples.leshkov.sippo.extremum.data;

public class DataUnit {
	private double a;
	private double b;
	private double epsilon;
	private int iterations;

	public DataUnit(double a, double b, double epsilon, int iterations) {
		this.a = a;
		this.b = b;
		this.epsilon = epsilon;
		this.iterations = iterations;
	}

	public double getA() {
		return a;
	}

	public double getB() {
		return b;
	}

	public double getEpsilon() {
		return epsilon;
	}

	public int getIterations() {
		return iterations;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		DataUnit dataUnit = (DataUnit) o;

		if (Double.compare(dataUnit.a, a) != 0) return false;
		if (Double.compare(dataUnit.b, b) != 0) return false;
		if (Double.compare(dataUnit.epsilon, epsilon) != 0) return false;
		return iterations == dataUnit.iterations;
	}

	@Override
	public int hashCode() {
		int result;
		long temp;
		temp = Double.doubleToLongBits(a);
		result = (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(b);
		result = 31 * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(epsilon);
		result = 31 * result + (int) (temp ^ (temp >>> 32));
		result = 31 * result + iterations;
		return result;
	}
}
