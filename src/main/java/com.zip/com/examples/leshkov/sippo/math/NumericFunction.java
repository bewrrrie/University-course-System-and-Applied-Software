package com.examples.leshkov.sippo.math;

public interface NumericFunction<X extends Number, Y extends Number> extends Function<X, Y> {}
