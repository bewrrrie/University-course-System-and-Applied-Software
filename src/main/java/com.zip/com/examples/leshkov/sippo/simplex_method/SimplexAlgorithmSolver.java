package com.examples.leshkov.sippo.simplex_method;

public class SimplexAlgorithmSolver {

}
