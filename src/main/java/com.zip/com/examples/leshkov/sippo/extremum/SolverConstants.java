package com.examples.leshkov.sippo.extremum;

public interface SolverConstants {
    int DICHOTOMY_MAX_ITER = 1000000;
    int FIBONACCI_MAX_ITER = 50;
    int GOLD_SECTION_MAX_ITER = 1000000;
    int QUADRATIC_INTERPOLATION_MAX_ITER = 1000000;
}
